import { useState } from "react";
import axios from "axios";

function SaveOffice() {
  const [officeName, setOfficeName] = useState("");
  const [officeNumber, setOfficeNumber] = useState("");

  const saveOffice = () => {
    const office = {
      name: officeName,
      officeNumber: Number(officeNumber),
    };

    axios
      .post("http://localhost:8082/api/offices/save", office)
      .then((response) => {
        alert(response.data);
      })
      .catch((error) => {
        if (!error.response) {
          alert("Cannot reach the backend. Check that Spring Boot is running on port 8082.");
        } else if (Array.isArray(error.response.data)) {
          alert(error.response.data.join("\n"));
        } else if (typeof error.response.data === "string") {
          alert(error.response.data);
        } else {
          alert("The backend rejected the request with status " + error.response.status + " but sent no message.");
        }
      });
  };

  return (
    <center>
      <h1>Save Office</h1>
      <p>
        <label htmlFor="officeName">Office Name: </label>
        <input
          id="officeName"
          name="officeName"
          type="text"
          value={officeName}
          onChange={(event) => setOfficeName(event.target.value)}
        />
      </p>
      <p>
        <label htmlFor="officeNumber">Office Number: </label>
        <input
          id="officeNumber"
          name="officeNumber"
          type="number"
          value={officeNumber}
          onChange={(event) => setOfficeNumber(event.target.value)}
        />
      </p>
      <button onClick={saveOffice}>Save Office</button>
    </center>
  );
}

export default SaveOffice;